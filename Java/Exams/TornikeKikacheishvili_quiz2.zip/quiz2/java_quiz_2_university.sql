INSERT INTO java_quiz_2.university (id, name, address, phone, headmaster) VALUES (2, 'tesada', 'adaedea', '38886686', 'aedaedaed');
