package com.example.task3;

public class University {
    private int id;
    private String name;
    private String address;
    private String phone;
    private String headmaster;

    public University(int id, String name, String address, String phone, String headmaster) {
        this.id = id;
        this.name = name;
        this.address = address;
        this.phone = phone;
        this.headmaster = headmaster;
    }
}
